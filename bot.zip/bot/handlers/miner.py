from aiogram import Router
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.filters import Command
from aiogram.filters.state import StateFilter
from aiogram.utils.keyboard import InlineKeyboardBuilder
import random



miner_router = Router()

class MinerStates(StatesGroup):
    playing = State()

GRID_SIZE = 5
MINES_COUNT = 5

def generate_field():
    field = [0] * (GRID_SIZE * GRID_SIZE)
    mines_positions = random.sample(range(GRID_SIZE * GRID_SIZE), MINES_COUNT)
    for pos in mines_positions:
        field[pos] = 1
    return field

def count_adjacent_mines(pos, field):
    row = pos // GRID_SIZE
    col = pos % GRID_SIZE
    count = 0
    for r in range(max(0, row-1), min(GRID_SIZE, row+2)):
        for c in range(max(0, col-1), min(GRID_SIZE, col+2)):
            idx = r * GRID_SIZE + c
            if field[idx] == 1:
                count += 1
    return count

def reveal_empty_cells(start_idx, revealed, field):
    """Рекурсивно открывает все пустые клетки вокруг"""
    stack = [start_idx]
    while stack:
        idx = stack.pop()
        if revealed[idx]:
            continue
        revealed[idx] = True
        if count_adjacent_mines(idx, field) == 0:
            row = idx // GRID_SIZE
            col = idx % GRID_SIZE
            for r in range(max(0, row - 1), min(GRID_SIZE, row + 2)):
                for c in range(max(0, col - 1), min(GRID_SIZE, col + 2)):
                    new_idx = r * GRID_SIZE + c
                    if not revealed[new_idx] and field[new_idx] == 0:
                        stack.append(new_idx)
    return revealed

def build_keyboard(revealed, field):
    builder = InlineKeyboardBuilder()
    for i in range(GRID_SIZE * GRID_SIZE):
        if revealed[i]:
            if field[i] == 1:
                text = "💣"
            else:
                mines_around = count_adjacent_mines(i, field)
                text = str(mines_around) if mines_around > 0 else "⬜"
        else:
            text = "▪️"
        builder.button(text=text, callback_data=f"cell_{i}")
    builder.adjust(GRID_SIZE)
    return builder.as_markup()

@miner_router.message(Command("miner"))
async def cmd_start_miner(message: Message, state: FSMContext):
    field = generate_field()
    revealed = [False] * (GRID_SIZE * GRID_SIZE)
    await state.update_data(field=field, revealed=revealed)
    keyboard = build_keyboard(revealed, field)
    await message.answer("Игра Минер началась! Выбирайте клетку.", reply_markup=keyboard)
    await state.set_state(MinerStates.playing)

@miner_router.callback_query(StateFilter(MinerStates.playing), lambda c: c.data and c.data.startswith("cell_"))
async def process_cell_callback(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    field = data.get("field")
    revealed = data.get("revealed")

    idx = int(callback.data.split("_")[1])
    if revealed[idx]:
        await callback.answer("Эта клетка уже открыта!", show_alert=True)
        return

    if field[idx] == 1:
        revealed[idx] = True
        keyboard = build_keyboard(revealed, field)
        await callback.message.edit_text("💥 Бомба! Вы проиграли!", reply_markup=keyboard)
        await callback.answer()
        await state.clear()
        return

    # Если кликнули по пустой клетке, запускаем рекурсивное открытие
    if count_adjacent_mines(idx, field) == 0:
        revealed = reveal_empty_cells(idx, revealed, field)
    else:
        revealed[idx] = True

    keyboard = build_keyboard(revealed, field)
    await state.update_data(revealed=revealed)

    safe_cells_count = GRID_SIZE * GRID_SIZE - MINES_COUNT
    if sum(revealed[i] for i in range(len(revealed)) if field[i] == 0) == safe_cells_count:
        await callback.message.edit_text("🎉 Поздравляем! Вы выиграли!", reply_markup=keyboard)
        await callback.answer()
        await state.clear()
        return

    await callback.message.edit_reply_markup(reply_markup=keyboard)
    await callback.answer("Клетка открыта.")