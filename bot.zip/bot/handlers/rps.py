from aiogram import Router
from aiogram.types import Message
from aiogram.filters import Command
import random

rps_router = Router()

@rps_router.message(Command("rps"))
async def cmd_rps(message: Message):
    await message.answer(
        "Игра Камень-Ножницы-Бумага!\nВыберите: /rock, /paper или /scissors"
    )

@rps_router.message(Command("rock"))
async def cmd_rock(message: Message):
    await play_rps(message, "камень")

@rps_router.message(Command("paper"))
async def cmd_paper(message: Message):
    await play_rps(message, "бумага")

@rps_router.message(Command("scissors"))
async def cmd_scissors(message: Message):
    await play_rps(message, "ножницы")

async def play_rps(message: Message, user_choice: str):
    choices = ["камень", "ножницы", "бумага"]
    bot_choice = random.choice(choices)

    wins = {
        "камень": "ножницы",
        "ножницы": "бумага",
        "бумага": "камень"
    }

    if user_choice == bot_choice:
        result = "Ничья!"
    elif wins[user_choice] == bot_choice:
        result = "Вы выиграли!"
    else:
        result = "Вы проиграли!"

    await message.answer(f"Вы: {user_choice}\nБот: {bot_choice}\n{result}")