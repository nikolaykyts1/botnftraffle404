from aiogram import Router
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
import random




coin_router = Router()

class CoinStates(StatesGroup):
    waiting_for_choice = State()

@coin_router.message(Command("coin"))
async def cmd_coin(message: Message, state: FSMContext):
    builder = InlineKeyboardBuilder()
    builder.button(text="Орел 🦅", callback_data="coin_heads")
    builder.button(text="Решка 🪙", callback_data="coin_tails")
    builder.adjust(2)

    await message.answer("Выбери сторону монетки:", reply_markup=builder.as_markup())
    await state.set_state(CoinStates.waiting_for_choice)

@coin_router.callback_query(CoinStates.waiting_for_choice)
async def coin_result(callback: CallbackQuery, state: FSMContext):
    user_choice = callback.data.split("_")[1]  # heads or tails
    coin_flip = random.choice(["heads", "tails"])

    result_text = (
        f"Монетка: {'Орел 🦅' if coin_flip == 'heads' else 'Решка 🪙'}\n\n"
        f"{'🎉 Ты угадал!' if user_choice == coin_flip else '😢 Ты не угадал.'}"
    )

    await callback.message.edit_text(result_text)
    await callback.answer()
    await state.clear()