from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
import random

guess_router = Router()

class GuessStates(StatesGroup):
    waiting_for_guess = State()

@guess_router.message(Command("guess"))
async def cmd_guess(message: Message, state: FSMContext):
    number = random.randint(1, 20)
    await state.update_data(number=number)
    await message.answer("Я загадал число от 1 до 20. Попробуй угадать!")
    await state.set_state(GuessStates.waiting_for_guess)

@guess_router.message(GuessStates.waiting_for_guess)
async def guess_number(message: Message, state: FSMContext):
    data = await state.get_data()
    number = data.get("number")

    try:
        guess = int(message.text)
    except ValueError:
        await message.answer("Пожалуйста, введи число.")
        return

    if guess == number:
        await message.answer("Поздравляю! Вы угадали число!")
        await state.clear()
    elif guess < number:
        await message.answer("Загаданное число больше.")
    else:
        await message.answer("Загаданное число меньше.")