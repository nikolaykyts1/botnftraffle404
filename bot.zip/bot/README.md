# Mini-Games Telegram Bot

Бот с мини-играми на базе aiogram 3. Содержит статистику и таблицу лидеров.