# db.py

def get_user_stats(user_id: int):
    # Заглушка — здесь может быть запрос в базу данных
    return {
        "miner": 0,
        "rps": 0,
        "guess": 0,
        "coin": 0
    }